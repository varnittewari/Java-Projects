package Nodes;
import Util.*;

/**
 * Created by Varnit Tewari on 2/28/2017.
 */

public class NegationNode extends UnaryOperatorNode {
    /**
     * constructor
     * @param child child
     */
    public NegationNode(MerpNode child){
        super(child,Precedence.MULT_DIVIDE,"_");
    }
    /**
     * evaluates the node
     * @param symbolTable the symbol table to use for variable processing
     * @return int
     */
    public int evaluate(SymbolTable symbolTable){
        return -child.evaluate(symbolTable);
    }
}
