package poly.stu;

/**
 * This code finds the derivative of the function of x and puts them in a list
 * Created by Varnit Tewari(vxt6823@rit.edu) on 1/28/2017.
 */
import java.util.ArrayList;
public class PolyDerive
{
    /**
     *  finds the derivative of the function of x and puts them in a list and then returns the list
     * @param poly list of numbers
     * @return list of derivatives
     */
    public static ArrayList<Integer> computeDerivative(ArrayList<Integer> poly){
        ArrayList<Integer> D = new ArrayList<>();
        for(int i = 1; i < poly.size(); i++){
            D.add(poly.get(i)*i);
        }
        return D;
    }

}
