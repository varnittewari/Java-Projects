/**
 * Created by Varnit Tewari on 2/18/2017.
 */
public class Circuit extends MultiComponent {
    /**
     * maximum capacity for this circuit (amps) before it is overloaded.
     */
    private int maxCapacity;

    /**
     * Constructor for a Circuit. Any type of source Component is allowed when creating the Circuit object, but only a
     * source that is a Circuit will allow this Circuit to be added successfully to the system (as a child of the source).
     * @param name name of the circuit
     * @param source component it is connected to
     * @param maxCapacity current that this circuit can hold
     */
    public Circuit(String name, MultiComponent source, int maxCapacity){
        super(name,source);
        this.maxCapacity=maxCapacity;
    }

    /**
     * add a Component to this circuit. The object must be a Circuit or a Receptacle. Appliances can not be directly
     * added to a Circuit - they must be connected through a Receptacle.
     * @param el component to e added
     * @return boolean if its added or not
     */
    public boolean add(Component el){
        if (el instanceof Appliance){
            return false;
        }else{
            children.add(el);
            return true;
        }
    }

    /**
     * Output a string representation of this Circuit and its children.
     * @param offset indentation
     */
    protected void display(String offset){
        String circhild="";
        for (int i=0;i<children.size();i++){
            circhild+="\n"+children.get(i).name+offset;
        }
        System.out.println("Circuit and its children are "+circhild);
    }

    /**
     * Update current usage within this Circuit. A Circuit has a limit on current, so this may cause a failure (overload).
     * If so, it immediately triggers a reset operation from this Circuit downward. It also triggers a new updateCurrent
     * call to update up the chain that this reset has occurred. If no overload occurs, the current is adjusted and the
     * operation is passed upward.
     * @param deltaCurrent change in current
     * @return name of the circuit that overloaded
     */
    protected void updateCurrent(int deltaCurrent) {
        if (currCurrent+deltaCurrent > maxCapacity) {
            reset();
            System.out.println("Overloaded circuit is "+getName());
        } else {
            currCurrent += deltaCurrent;
            if (!source.getName().equals("ROOT")) {
                source.updateCurrent(deltaCurrent);
            }
        }
    }

    /**
     * resets the circuit to be carrying no current and sends the command to its children and sources to change the carrying current.
     */
    public void reset(){
        for (Component i:children){
            i.reset();
        }
        if (!source.getName().equals("ROOT")){
            source.updateCurrent(-currCurrent);
        }
        currCurrent=0;
    }
}
