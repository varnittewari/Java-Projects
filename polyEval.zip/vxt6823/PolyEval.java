package poly.stu;

/**
 * This file computes the function of x and finds the value and checks if the function is zero or not.
 * Created by Varnit Tewari(vxt6823@rit.edu) on 1/27/2017.
 */
import java.util.ArrayList;
public class PolyEval
{
    /**
     * This function evaluates the function of x
     * @param poly list of numbers
     * @param x value of x
     * @return value of f(x)
     */
    public static double evaluate(ArrayList<Integer> poly, double x) {
        double y=0;
    for (int i=0;i<poly.size();i++){
        y+=poly.get(i)*Math.pow(x,i);
        }return y;

    }

    /**
     * This checks if the function of x is zero or not
     * @param poly list of numbers
     * @return boolean
     */
    public static boolean isZero(ArrayList<Integer> poly)
    {
        int i=0;
        while (i<poly.size()){

            if (poly.get(i)!=0) {
                return false;
            }
            i += 1;
            }
            return true;
    }
}

