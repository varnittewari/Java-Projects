/**
 * Created by varni on 2/24/2017.
 */
public class Professor extends User {

    public Professor(String username) {
        /**
         * Create a new professor.
         */
        super(username,UserType.PROFESSOR, new ClassComparator1());
    }
}
