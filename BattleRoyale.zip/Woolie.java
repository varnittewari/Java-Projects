import java.util.Random;

/**
 * Created by Varnit Tewari on 4/26/2017.
 */
public class Woolie {
    /**
     *
     */
    public static int seed;
    /**
     * name of the fighter
     */
    private String name;
    /**
     * minimum attack it can make
     */
    private int minAtk;
    /**
     * maximum attack it can make
     */
    private int maxAtk;
    /**
     * hitting time
     */
    private int ht;
    /**
     * maximum hitting points it has
     */
    private int maxhp;
    /**
     * current life
     */
    private int currentHp;

    /**
     * constructor
     * @param name name
     * @param minAtk int
     * @param maxAtk int
     * @param hitTime int
     * @param maxHP int
     */
    public Woolie(String name,
                  int minAtk,
                  int maxAtk,
                  int hitTime,
                  int maxHP){
        this.name=name;
        this.minAtk=minAtk;
        this.maxAtk=maxAtk;
        this.ht=hitTime;
        this.currentHp=maxHP;
    }

    /**
     * constructor to make from file
     * @param params list
     */
    public Woolie(String[] params){
        this.name=params[0];
        this.minAtk=Integer.parseInt(params[1]);
        this.maxAtk=Integer.parseInt(params[2]);
        this.ht=Integer.parseInt(params[3]);
        this.maxhp=Integer.parseInt(params[4]);
        this.currentHp=maxhp;
    }

    /**
     * gets the name
     * @return string
     */
    public String getName(){
        return this.name;
    }

    /**
     * gets the current life
     * @return int
     */
    public int getCurrentHP(){
        return this.currentHp;
    }

    /**
     * gets the attack amount
     * @return int
     */
    public int getAttackAmount(){
        Random random = new Random();
        int plus = random.nextInt(maxAtk-minAtk+1);
        return minAtk+plus;
    }

    /**
     * gets the damage done
     * @param damage
     */
    public void takeDamage(int damage){
        this.currentHp=currentHp-damage;
    }

    /**
     * converts to string
     * @return string
     */
    @Override
    public String toString() {
        return "Woolie{" +
                "name='" + name + '\'' +
                ", minAtk=" + minAtk +
                ", maxAtk=" + maxAtk +
                ", ht=" + ht +
                ", maxhp=" + maxhp +
                '}';
    }

    /**
     * checks if the woolie is alive or not
     * @return boolean
     */
    public boolean isOK(){
        return (getCurrentHP()>0);
    }

    /**
     * gets the hitting itme
     * @return int
     */
    public int getHitTime(){
        return this.ht;
    }

    /**
     * resets the life of woolie
     */
    public void reset(){
        this.currentHp=maxhp;
    }

}
