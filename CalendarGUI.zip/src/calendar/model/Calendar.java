package calendar.model;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

/**
 * Created by Varnit Tewari on 4/12/2017.
 */
public class Calendar extends Observable {
    /**
     * saves the file name in it
     */
    private String saveFile;
    /**
     * number of months
     */
    private final int monthSize;
    /**
     * list of list of ppointments
     */
    private List<List<Appointment>> appointments;

    /**
     * Constructor
     * @param monthSize int
     */
    public Calendar(int monthSize){
        appointments= new ArrayList<>();
        this.monthSize=monthSize;
        for (int i=0;i<monthSize;i++){
            ArrayList<Appointment> app=new ArrayList<>(monthSize);
            appointments.add(app);
        }
    }

    /**
     * makes an apointment from file
     * @param fileName string
     * @return calendar
     * @throws java.io.IOException
     */
    public static Calendar fromFile(String fileName)
            throws java.io.IOException{
        Calendar cal;
        try {
            Scanner sc = new Scanner(new File(fileName));
            int numMonth = Integer.parseInt(sc.nextLine());
            cal = new Calendar(numMonth);
            while (sc.hasNextLine()) {
                String line = sc.nextLine();
                String[] data=line.split(",");
                int newDate=Integer.parseInt(data[0]);
                String[] timings=data[1].split(":");
                int hr=Integer.parseInt(timings[0]);
                int min=Integer.parseInt(timings[1]);
                Time newTime=new Time(hr,min);
                cal.add(newDate,newTime,data[2]);
            }
            sc.close();
        } catch( NumberFormatException nfe ) {
            throw new IOException( nfe );
        }
        cal.saveFile=fileName;
        return cal;
    }

    /**
     * converts the calendar to file
     * @throws java.io.IOException
     */
    public void toFile()
            throws java.io.IOException {
        if (this.saveFile == null) {
            throw new IOException("Calendar not loaded from a file.");
        }
        try (PrintWriter calFile = new PrintWriter(this.saveFile)) {
            calFile.println(this.monthSize);
            for (List<Appointment> app : this.appointments)
            {
                if (!app.isEmpty())
                {
                    for(Appointment ap : app)
                    {
                        calFile.println(ap.csvFormat());
                    }
                }
            }
        }
    }

    /**
     * gets the number of months
     * @return int
     */
    public int numDays(){
        return monthSize;
    }

    /**
     * adds an appointment to the list of appointments
     * @param appt appointment
     */
    public void add(Appointment appt){
        int date0=appt.getDate();
        List<Appointment> apptlist=this.appointments.get(date0-1);
        apptlist.add(appt);
        dateChanged(date0);
    }

    /**
     * removes the appointments
     * @param appt appointment
     */
    public void remove(Appointment appt){
        int date0=appt.getDate();
        List<Appointment> lst=appointments.get(date0-1);
        lst.remove(appt);
        dateChanged(date0);
    }

    /**
     * * adds an appointment to the list of appointments
     * @param date int
     * @param time time
     * @param what string
     */
    public void add(int date,
                    Time time,
                    String what){
        Appointment appt=new Appointment(date,time,what);
        appointments.get(date-1).add(appt);
        dateChanged(date);
    }

    /**
     * gets the list of appointments
     * @param date int
     * @return list
     */
    public List<Appointment> appointmentsOn(int date){
        return appointments.get(date-1);
    }

    /**
     * updates the date
     * @param date int
     */
    void dateChanged(int date){
        setChanged();
        notifyObservers(date);
    }
}
