/**
 * Created by varni on 2/24/2017.
 */

import java.util.Collection;
import java.util.*;

public class UserDB implements DB<String,User> {
    /**
     * user storage
     */
    private HashMap<String,User> users;

    /**
     * initializes the users
     */
    public UserDB(){
        users=new HashMap<>();
    }

    /**
     * adds a value to the user
     * @param user user
     * @return user
     */
    public User addValue(User user){
        User val1= users.get(user.getUsername());
        users.put(user.getUsername(),user);
        return val1;
    }

    /**
     * gets the value
     * @param username name of the user
     * @return user
     */
    public User getValue(String username){
        return users.get(username);
    }

    /**
     * checks if it has the key
     * @param username name of the user
     * @return boolean
     */
    public boolean hasKey(String username){
        return users.containsKey(username);
    }

    /**
     * gets all the values
     * @return users
     */
    public Collection<User> getAllValues(){
        return users.values();
    }
}
