package Nodes;
import Util.*;
import java.lang.Math;

/**
 * Created by Varnit Tewari on 2/28/2017.
 */

public class SquareRootNode extends UnaryOperatorNode {
    /**
     * constructor
     * @param child child
     */
    public SquareRootNode(MerpNode child){
        super(child,Precedence.POWER,"@");
    }
    /**
     * evaluates the node
     * @param symbolTable the symbol table to use for variable processing
     * @return int
     */
    public int evaluate(SymbolTable symbolTable){
        return (int)Math.sqrt(child.evaluate(symbolTable));
    }
}
