package Nodes;
import Util.*;

/**
 * Created by Varnit Tewari on 2/28/2017.
 */
public class LessThanNode extends BooleanOperatorNode {
    /**
     * constructor
     * @param left child
     * @param right child
     */
    public LessThanNode(MerpNode left, MerpNode right){
        super(left,right,"<");
    }
    /**
     * evaluates the node
     * @param symbolTable the symbol table to use for variable processing
     * @return int
     */
    public int evaluate(SymbolTable symbolTable){
        if (leftChild.evaluate(symbolTable)<rightChild.evaluate(symbolTable)){
            return 1;
        }
        return 0;
    }
}
