/**
 * Created by Varnit Tewari on 2/18/2017.
 */
import java.util.ArrayList;
import java.util.Scanner;
public class PanelSimulator {
    /**
     * list made to save everything that is being passed
     */
    public static ArrayList<Component> newList;

    public PanelSimulator(){
    }

    /**
     * Run simulation. Read input from System.in. User-input loop accepts following commands:
     A (for add) followed by:
     C name sourceName maxCurrent (circuit add)
     R name sourceName maxAttach (receptacle add)
     A name sourceName reqCurr (appliance add)
     T (for toggle use) followed by:
     name (for appliance)
     D (for display) followed by:
     name (for component)
     Q (for quit)
     */
    public static void runSimulation(){
        Circuit cir=new Circuit("ROOT",null,0);
        newList= new ArrayList<Component>();
        newList.add(cir);
        while(true){
            System.out.println("Enter a request");
            Scanner in= new Scanner(System.in);
            String cmd= in.next();
            switch (cmd) {
                case "A":
                    String comp = in.next();
                    String childName = in.next();
                    for (int j=0;j<newList.size();j++){
                        if (newList.get(j).getName().equals(childName)){
                            System.out.println("Component of same name found");
                            break;
                        }
                    String parentName = in.next();
                    Component C1=null;
                    for (int i=0;i<newList.size();i++){
                        if (newList.get(i).getName().equals(parentName)){
                            C1=newList.get(i);
                        }
                    }if (C1==null) {
                            System.out.println("Error because C1 is null");
                            break;
                        }
                        MultiComponent C;
                    if (!(C1 instanceof Appliance)) {
                            C = (MultiComponent) C1;
                        }else {
                        System.out.println("Error");
                        break;
                        }
                        String num = in.next();

                    int maxCap=Integer.parseInt(num);
                    if (comp.equals("C")) {
                       Circuit Cir=new Circuit(childName,C,maxCap);

                       boolean added = C.add(Cir);
                        if (added){
                            newList.add(Cir);
                            System.out.println("Circuit '"+ childName+"' added successfully");
                        }else{
                            System.out.println("Was not able to add the Circuit ");
                        }
                        break;
                    }else if(comp.equals("R")){
                        Receptacle rec= new Receptacle(childName,C,maxCap);

                        boolean added1=C.add(rec);
                        if (added1){
                            newList.add(rec);
                            System.out.println("Receptacle '"+childName+"' added successfully");
                        }else{
                            System.out.println("Was not able to add the receptacle ");
                        }
                        break;
                    }else{
                        Appliance app=new Appliance(childName,C,maxCap);

                        boolean added2 = C.add(app);
                        if (added2){
                            newList.add(app);
                            if (C.equals("ROOT")){
                                System.out.println("Circuit '"+childName+"' added as a Root circuit");
                            }else {
                                System.out.println("Appliance '" + childName + "' added successfully");
                            }
                        } else{
                            System.out.println("Was not able to add the Appliance");
                        }
                        break;
                    }}
                    break;
                case "T":
                    boolean sad = false;
                    String app = in.next();
                    Component C2 = null;
                    for (int i=0;i<newList.size();i++){
                        if (newList.get(i) instanceof Appliance){
                            if (newList.get(i).name.equals(app)){
                                C2=newList.get(i);
                                Appliance app1 = (Appliance) C2;
                                app1.toggleUsage();
                                System.out.println(app+" turned on");
                                sad = true;
                                break;
                            }
                        }
                    }
                    if(!sad){
                        System.out.println("Error");
                    }
                    break;
                case "D":
                    String compName = in.next();
                    Component C1=null;
                    for (int i=0;i<newList.size();i++){
                        if (newList.get(i).name.equals(compName)){
                            C1=newList.get(i);
                        }
                    }
                    if (C1==null){
                        System.out.println("Error");
                        break;
                    }else{
                    if (C1 instanceof Circuit){
                        C1.display("    ");
                    }else if(C1 instanceof Receptacle){
                        C1.display("    ");
                    }else{
                        C1.display("    ");
                    }}
                    break;
                case "Q":
                    System.out.println("Quitting");
                    return ;
            }
        }
    }

    /**
     * Main method. Calls static method to run simulation. Command line arguments are not used. All input is received
     * through System.in
     * @param args
     */
    public static void main(String[] args){
        runSimulation();
    }

            }
