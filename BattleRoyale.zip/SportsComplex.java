import java.awt.*;

/**
 * Created by Varnit Tewari on 4/26/2017.
 */
public class SportsComplex {
    /**
     * number of free arenas
     */
    private int numArenas;

    /**
     * constructor for sportcomplex
     * @param maxInUse max arenas
     */
    public SportsComplex(int maxInUse){
        this.numArenas=maxInUse;
    }

    /**
     * fighters enter the arena
     * @param t thread class
     */
    public synchronized void enterArena(WoolieBattleThread t){
        if (numArenas>0){
            numArenas--;
        }
        else {
            while (true) {
                try {
                    t.sleep(1000);
                } catch (InterruptedException in) {

                }
                if (numArenas > 0) {
                    numArenas--;
                    break;
                }
            }
        }
    }

    /**
     * fighters exit the arena
     */
    public void leaveArena(){
        numArenas++;
    }
}
