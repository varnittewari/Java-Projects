package Nodes;

/**
 * Created by Varnit Tewari on 2/28/2017.
 */
public abstract class BinaryOperatorNode extends java.lang.Object implements MerpNode {
    /**
     * the left child
     */
    protected MerpNode leftChild;
    /**
     * the right child
     */
    protected MerpNode rightChild;
    /**
     * the precedence
     */
    protected Precedence precedence;
    /**
     * the operator
     */
    protected java.lang.String operator;

    /**
     * Binary Node Constructor
     * @param leftChild
     * @param rightChild
     * @param precedence
     * @param operator
     */
    public BinaryOperatorNode(MerpNode leftChild, MerpNode rightChild, Precedence precedence, java.lang.String operator){
        this.leftChild=leftChild;
        this.rightChild=rightChild;
        this.precedence=precedence;
        this.operator=operator;
    }

    /**
     * sets the left child
     * @param leftChild
     */
    public void setLeftChild(MerpNode leftChild){
        this.leftChild=leftChild;
    }

    /**
     * sets the right child
     * @param rightChild
     */
    public void setRightChild(MerpNode rightChild){
        this.rightChild=rightChild;
    }

    /**
     * converts to a prefix string
     * @return string
     */
    public java.lang.String toPrefixString(){
        return operator+" "+leftChild.toPrefixString()+" "+rightChild.toPrefixString();
    }

    /**
     * converts to an infix string
     * @return string
     */
    public java.lang.String toInfixString(){
        return "("+leftChild.toInfixString()+" "+operator+" "+rightChild.toInfixString()+")";
    }

    /***
     * converts to a postfix string
     * @return sting
     */
    public java.lang.String toPostfixString(){
        return leftChild.toPostfixString()+" "+rightChild.toPostfixString()+" "+operator;
    }

    /**
     * gets the precedence
     * @return int
     */
    public int getPrecedence(){
        return this.precedence.getPrecedence();
    }

    /**
     * checks if its an operator or not
     * @return boolean
     */
    public boolean isOperation(){
        return true;
    }

    /**
     * gets the type of node
     * @return
     */
    public MerpNode.NodeType getNodeType(){
        return NodeType.BinaryOperation;
    }
}
