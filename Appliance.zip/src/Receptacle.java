

/**
 * Created by Varnit Tewari on 2/18/2017.
 */
public class Receptacle extends MultiComponent {
    /**
     * maximum number of children
     */
    private int maxChildrenl;

    /**
     * Constructor for a Receptacle. Constructor does not check that the source is correct type of Component (must be a
     * Receptacle or Circuit). This is checked when this element is attempted to be added to the system.
     * @param name name of the receptacle
     * @param source source it is connected to
     * @param maxEl max elements it coul be connected to
     */
    public Receptacle(String name, MultiComponent source, int maxEl){
        super(name,source);
        this.maxChildrenl=maxEl;
    }

    /**
     * dd a Component to this Receptacle. The object must be another Receptacle (e.g. a 6-pack power strip) or an
     * Appliance (e.g. a toaster). Moreover, there must still remain an available socket (e.g. space for plug in a wall
     * outlet) for this Receptacle to add another child.
     * @param el element to be added
     * @return boolean if tis added or not
     */
    public boolean add(Component el){
        if (maxChildrenl>0){
            if (el instanceof Circuit){
                return false;
            }else{
                children.add(el);
                maxChildrenl-=1;
                return true;
            }
        }else{
            return false;
        }
    }

    /**
     * Output a string representation of this Receptacle and its children.
     * @param offset indent
     */
    protected void display(String offset){
        String recchild="";
        for (int i=0;i<children.size();i++){
                    recchild+="\n"+children.get(i).name+offset;
                }
        System.out.println("Circuit and its children are "+recchild);
    }

    /**
     * it updates the current and checks if its overloaded or not. if its overloaded , it goes and finds the circuit thats
     * overloaded and resets the whole system
     * @param deltaCurrent change in current
     * @return name of the circuit if its overloaded, else null
     */
    protected void updateCurrent(int deltaCurrent) {
        currCurrent+=deltaCurrent;
        source.updateCurrent(deltaCurrent);
    }

    /**
     * resets the systm and its children
     */
    public void reset(){
        for (Component i:children){
            i.reset();
            }
            currCurrent=0;
    }
}
