/**
 * Created by Varnit Tewari on 2/22/2017.
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
public class BackEnd {
    /**
     * the database of courses
     */
    private CourseDB courseDB;
    /**
     * the database of users
     */
    private UserDB userDB;

    /**
     * Creates the backend by initializing the course and user databases.
     * @param courseFile the file of courses
     * @param professorFile the file of professors
     * @param studentFile the file of students
     * @throws FileNotFoundException
     */
    public BackEnd(String courseFile, String professorFile, String studentFile) throws FileNotFoundException {
        courseDB= new CourseDB();
        userDB= new UserDB();
       initializeCourseDB(courseFile);
       initializeUserDB(professorFile,studentFile);
    }

    /**
     * A utility method for initializing the course database.
     * @param courseFile name of the course file
     * @throws FileNotFoundException
     */
    private void initializeCourseDB(String courseFile) throws FileNotFoundException  {
        try (Scanner in = new Scanner(new File(courseFile))) {
            while (in.hasNext()) {
                String[] fields = in.nextLine().split(",");
                String id = fields[0];
                String name = fields[1];
                String level = fields[2];
                Course c = new Course(Integer.parseInt(id), name, Integer.parseInt(level));
                courseDB.addValue(c);
            }
        }
    }

    /**
     * A utility method for initializing the user database.
     * @param professorFile name of the professor file
     * @param studentFile name of the student file
     * @throws FileNotFoundException
     */
    private void initializeUserDB(String professorFile, String studentFile) throws FileNotFoundException {
        try (Scanner in = new Scanner(new File(professorFile))) {
            while (in.hasNext()) {
                String[] fields = in.nextLine().split(",");
                String proname=fields[0];
                User pro= new Professor(proname);
                addCourses(pro,fields);
                userDB.addValue(pro);
            }
        }

        try (Scanner in = new Scanner(new File(studentFile))) {
            while (in.hasNext()) {
                String[] fields = in.nextLine().split(",");
                String stuname=fields[0];
                User pro= new Student(stuname);
                userDB.addValue(pro);
                addCourses(pro,fields);
            }
        }
    }

    /**
     * A utility "utility" method. Used by initializeUserDB when adding a professor or student to a collection of courses.
     * @param user user
     * @param courseIds to find courses
     */
    private void addCourses(User user, String[] courseIds) {
        if (user.getType()== User.UserType.PROFESSOR) {
            for (int i = 1; i < courseIds.length; i++) {
                Course c11=getCourse(Integer.parseInt(courseIds[i]));
                user.addCourse(c11);
                c11.addProfessor(user.getUsername());
            }
        }else {
            for (int i = 1; i < courseIds.length; i++){
                enrollStudent(user.getUsername(),Integer.parseInt(courseIds[i]));
            }
        }
    }

    /**
     * to check if th course existsor not
     * @param id id
     * @return boolean
     */
    public boolean courseExists(int id){
        return courseDB.hasKey(id);
    }

    /**
     * to enroll student to course
     * @param username name of the student
     * @param courseId course
     * @return boolean
     */
    public boolean enrollStudent(String username, int courseId){
        if (userDB.getAllValues().contains(username)){
            return false;
        }else{
            Course cou=getCourse(courseId);
            User stu=userDB.getValue(username);
            stu.addCourse(cou);
            cou.addStudent(username);
            return true;
        }
    }

    /**
     * gets all courses
     * @return courses
     */
    public Collection<Course> getAllCourses(){
        return courseDB.getAllValues();
    }

    /**
     * gets all users
     * @return all users
     */
    public Collection<User> getAllUsers(){
        return userDB.getAllValues();
    }

    /**
     * checks if its a student
     * @param username
     * @return
     */
    public boolean isStudent(String username){
        if (getAllUsers().contains(username)){
            return true;
        }
        return false;
    }

    /**
     * gets the value of the course
     * @param id
     * @return
     */
    public Course getCourse(int id){
        return courseDB.getValue(id);
    }

    /**
     * unenrolls the student from the courses
     * @param username name of the student
     * @param courseId course
     * @return boolean
     */
    public boolean unenrollStudent(String username, int courseId){
        if (userDB.getAllValues().contains(username)){
            Course cou=getCourse(courseId);
            User stu1=userDB.getValue(username);
            stu1.removeCourse(cou);
            cou.removeStudent(username);
            return true;
        }
        return false;
    }

    /**
     * checks if the user exists or not
     * @param username name of the user
     * @return boolean
     */
    public boolean userExists(String username){
        return userDB.hasKey(username);
    }

    /**
     * gets all the courses
     * @param username name of the user
     * @return courses
     */
    public Collection<Course> getCoursesUser(String username){
        return userDB.getValue(username).getCourses();
    }
}
