package Lab2;

import java.util.ArrayList;

/**
 * Created by Varnit Tewari on 2/6/2017.
 */
public class ParkingLot {
    private int capacity;
    private int generalSpots;
    private int handicappedSpots;
    public static int ILLEGAL_SPOT;
    private ArrayList<ParkingSpot> lot;
    private int parkedVehicles;
    private int reservedSpots;
    private static int SPOTS_PER_LINE=10;

    /**
     * create a new parking lot
     * @param handicappedSpots
     * @param reservedSpots
     * @param generalSpots
     */
    public ParkingLot(int handicappedSpots, int reservedSpots, int generalSpots) {
        this.handicappedSpots = handicappedSpots;
        this.reservedSpots = reservedSpots;
        this.generalSpots = generalSpots;
        capacity = handicappedSpots+reservedSpots+generalSpots;
        lot = new ArrayList<ParkingSpot>();
        initializeSpots();
    }

    /**
     * Create the parking spots for the lot. This is a helper method that is called by the constructor,
     * after the lot has been created, to initialize and add each new spot to the lot.
     */
    private void initializeSpots() {
        for (int i = 0; i < handicappedSpots; i++)
        {
            ParkingSpot H = new ParkingSpot(i, Permit.Type.HANDICAPPED);
            lot.add(H);

        }
            for (int j = handicappedSpots; j < handicappedSpots+reservedSpots; j++)
            {
                ParkingSpot R = new ParkingSpot(j, Permit.Type.RESERVED);
                lot.add(R);
            }
                for (int k = handicappedSpots+reservedSpots; k < capacity; k++)
                {
                    ParkingSpot G = new ParkingSpot(k, Permit.Type.GENERAL);
                    lot.add(G);
                }
    }

    /**
     * gets the capacity
     * @return
     */
    public int getCapacity() {
        return this.capacity;
    }

    /**
     * gets the number of parked vehicles
     * @return
     */
    public int getNumParkedVehicles() {
        return this.parkedVehicles;
    }

    /**
     * checks if the spot is in the lot or not
     * @param spot
     * @return
     */
    public boolean isSpotValid(int spot) {
        boolean sv = false;
        if(spot < capacity && spot >= 0){
            sv = true;
        }
        return sv;
    }

    /**
     * gets the spot from the list
     * @param spot
     * @return
     */
    public ParkingSpot getSpot(int spot) {
        ParkingSpot ps = lot.get(spot);
        return ps;
    }

    /**
     * Tells whether a spot is in a valid range within the parking lot or not.
     * @param spot
     * @return
     */
    public boolean isSpotVacant(int spot) {
        Vehicle v = lot.get(spot).getVehicle();
        if (v==null){
    return true;
        }else{
            return false;
        }
    }

    /**
     * parks the vehicle at a given spot
     * @param vehicle
     * @param spot
     * @return
     */
    public boolean parkVehicle(Vehicle vehicle, int spot) {
        if (isSpotVacant(spot)) {
            ParkingSpot ps = lot.get(spot);
            ps.occupySpot(vehicle);
            parkedVehicles++;
            return true;
        }else{
            return false;
        }
    }

    /**
     * removes that specific vehicle
     * @param vehicle
     * @return
     */
    public int removeVehicle(Vehicle vehicle){
        boolean a=false;
        for (ParkingSpot i:lot) {
            if (i.getVehicle() == vehicle) {
                a = true;
                parkedVehicles--;
                i.vacateSpot();
                return i.getSpot();
            }
        }
         return ILLEGAL_SPOT;
    }


    /**
     * Return a string representation of the parking lot. The format is 10 spots per line,
     * with a space between each spot (hint, use the ParkingSpot's toString() to get each spot's string).
     * Once all spots are printed, on a new line print the number of vacant spots.
     * @return
     */
    public String toString() {
        String str = "";
        for (int i = 0; i < capacity; i = i + SPOTS_PER_LINE) {
            String row = "";
            if (SPOTS_PER_LINE + i < capacity) {
                for (int j = i; j < SPOTS_PER_LINE + i; j++) {
                    row+= lot.get(j).toString()+" ";
                }
            } else {
                for (int j = i; j < capacity; j++) {
                    row+= lot.get(j).toString()+" ";
                }
            }
        str += row+"\n";
        }
        int vs=capacity-parkedVehicles;
        str+= "Vacant spots:"+vs;
        return str;
    }

    /**
     * tester function for all the functions made
     * @param args
     */
    public static void main(String[] args){
        ParkingLot pl1=new ParkingLot(2,2,6);
        System.out.println("The capacity of the lot is 10?"+(pl1.getCapacity()==10?"Yes":"NO,GOT:"+pl1.getCapacity()));
        System.out.println("Parked vehicles are "+pl1.getNumParkedVehicles());
        System.out.println("Is spot 10 valid?"+(!pl1.isSpotValid(12)?"True":"False"));
        Vehicle v1= new Vehicle(123);
        System.out.println("Is vehicle parking successfully?"+(pl1.parkVehicle(v1,5)?"True":"False"));
        System.out.println("Remove vehicle?"+(pl1.removeVehicle(v1)==5 ? "Yes":"NO"));
        System.out.println(pl1.toString());

        ParkingLot pl2=new ParkingLot(2,2,6);
        System.out.println("The capacity of the lot is 10?"+(pl2.getCapacity()==10?"Yes":"NO,GOT:"+pl2.getCapacity()));
        System.out.println("Parked vehicles are "+pl2.parkedVehicles);
        System.out.println("Is spot 6 valid?"+(pl2.isSpotValid(6)?"True":"False"));
        Vehicle v2= new Vehicle(1234);
        System.out.println("Is vehicle parking successfully?"+(pl2.parkVehicle(v2,6)?"True":"False"));
        pl2.removeVehicle(pl2.getSpot(6).getVehicle());
        System.out.println(pl2.toString());

        ParkingLot pl3=new ParkingLot(2,2,6);
        System.out.println("The capacity of the lot is 10?"+(pl3.getCapacity()==10?"Yes":"NO,GOT:"+pl3.getCapacity()));
        System.out.println("Parked vehicles are "+pl3.parkedVehicles);
        System.out.println("Is spot 6 valid?"+(pl3.isSpotValid(6)?"True":"False"));
        Vehicle v3= new Vehicle(12345);
        System.out.println("Is vehicle parking successfully?"+(pl3.parkVehicle(v3,6)?"True":"False"));
        pl3.removeVehicle(pl3.getSpot(6).getVehicle());
        System.out.println("Is spot vacant?"+pl3.isSpotVacant(6));
        System.out.println(pl3.toString());
    }
}