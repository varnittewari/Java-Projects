package Nodes;
import Util.*;

/**
 * Created by Varnit Tewari on 2/28/2017.
 */

public class PowerNode extends BinaryOperatorNode {
    /**
     * constructor
     * @param left child
     * @param right child
     */
    public PowerNode(MerpNode left, MerpNode right){
        super(left,right,Precedence.POWER,"^");
    }
    /**
     * evaluates the node
     * @param symbolTable the symbol table to use for variable processing
     * @return int
     */
    public int evaluate(SymbolTable symbolTable){
        return (int)Math.pow(leftChild.evaluate(symbolTable),rightChild.evaluate(symbolTable));
    }
}
