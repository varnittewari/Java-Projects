package poly.stu;
import java.util.ArrayList;
import poly.stu.PolyEval;
import poly.stu.PolyDerive;
/**
 * It finds the closest root of the function.
 * Created by Varnit Tewari on 1/28/2017.
 */

public class PolyRoot
{
    public static double EPSILON=0.0001;
    public static double INITIAL_GUESS=0.1;
    public static int MAX_ITERATIONS=100;

    /**
     * checks if the function is not zero and then finds the root
     * @param poly
     * @return root
     */
    public static double computeRoot(ArrayList<Integer> poly){
        double x=0.0;
        if (PolyEval.isZero(poly)==false){
            x=newtonsMethod(poly,INITIAL_GUESS,0);
        }else{
            return 0;
        }
        return x;

    }

    /**
     * finds the root using the newtons method
     * @param poly Array list
     * @param x0 value of x
     * @param iter number of iterations
     * @return root
     */
    private static double newtonsMethod(ArrayList<Integer> poly, double x0, int iter)
    {
        double a=0.0;
        double b=0.0;
        a=PolyEval.evaluate(poly,x0);
        double x1=0.0;
        ArrayList<Integer> der= PolyDerive.computeDerivative(poly);

        b=PolyEval.evaluate(der,x0);
        x1=x0-(a/b);
        iter+=1;
        if (iter>MAX_ITERATIONS){
            return x0;
        }else if (a<=EPSILON && a>= -EPSILON) {
            return x0;
        }else{
            return newtonsMethod(poly,x1,iter);
        }

    }
}
