package Turtle;
import Turtle.StdDraw;
import Turtle.Turtle;
import java.util.ArrayList;

/**
 * Makes H using turtle
 * Created by Varnit Tewari(vxt6823@rit.edu) on 1/28/2017.
 */

public class HTree extends Object
/**
 * Makes a H
 */
{
    private static final int MAX_SEGMENT_LENGTH=1024;

    /**
     *
     * @param t turtle object
     * @param length lenght of H
     * @param depth number of H
     */
    public static void drawHTree(Turtle t, int length, int depth){
        if (depth>0) {
            t.goForward(length / 2);
            t.turnLeft(90);
            t.goForward(length / 2);
            t.turnRight(90);
            drawHTree(t, length / 2, depth - 1);
            t.turnRight(90);
            t.goForward(length);
            t.turnRight(90);
            drawHTree(t, length / 2, depth - 1);
            t.turnRight(90);
            t.goForward(length / 2);
            t.turnLeft(90);
            t.goForward(length);
            t.turnLeft(90);
            t.goForward(length / 2);
            t.turnRight(90);
            drawHTree(t, length / 2, depth - 1);
            t.turnRight(90);
            t.goForward(length);
            t.turnRight(90);
            drawHTree(t, length / 2, depth - 1);
            t.turnRight(90);
            t.goForward(length / 2);
            t.turnLeft(90);
            t.goForward(length / 2);
        }

    }

    /**
     * Initialization, makes a turtle object and sets the window.
     * @param length length of H
     * @param depth number of H
     * @return turtle object
     */
    public static Turtle init(int length, int depth) {
        Turtle t= new Turtle(0,0,0);
        StdDraw.setXscale(-MAX_SEGMENT_LENGTH*2, MAX_SEGMENT_LENGTH*2);
        StdDraw.setYscale(-MAX_SEGMENT_LENGTH*2, MAX_SEGMENT_LENGTH*2);
        return t;
    }

    /**
     * Its a main function and calls other functions to make H
     * @param args depth
     */
    public static void main(String[] args) {
        ArrayList<Integer> flynn = new ArrayList<>();
        for(String arg:args){
            flynn.add(Integer.parseInt(arg));
        }
        //int depth = Integer.parseInt(args[0]);
        int depth = flynn.get(0);
        if (depth <0){
            System.out.println("Depth must be greater than or equal to 0");
        }
        Turtle t=init(MAX_SEGMENT_LENGTH,depth);
        drawHTree(t,MAX_SEGMENT_LENGTH,depth);
    }

}
