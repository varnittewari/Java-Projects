package Processors;
import Nodes.*;

/**
 * Created by Varnit Tewari on 3/6/2017.
 */
public class MerpPrefixProcessor extends MerpProcessor {
    /**
     * constructor
     */
    public MerpPrefixProcessor() {
    }
    /**
     * constructs the trees
     * @param tokens list of IerpNodes used to create the pares tree
     */
    public void constructTree(java.util.ArrayList<java.lang.String> tokens) {
        tree = constructTreeHelper(tokens);
    }
    /**
     * helper methd for making the tree
     * @param tokens array list of tokens
     * @return tree
     */
    private MerpNode constructTreeHelper(java.util.ArrayList<java.lang.String> tokens) {
        String c=tokens.get(0);
        MerpNode t=createMerpNode(c);
        tokens.remove(0);
        if (isVariable(c) || (isNumeric(c))){
            return t;
        }
        else{
            if (t.getNodeType() == MerpNode.NodeType.UnaryOperation) {
                UnaryOperatorNode tree1= (UnaryOperatorNode) t;
                tree1.setChild(constructTreeHelper(tokens));
                return tree1;
            } else {
                BinaryOperatorNode tree1= (BinaryOperatorNode) t;
                tree1.setLeftChild(constructTreeHelper(tokens));
                tree1.setRightChild(constructTreeHelper(tokens));
                return tree1;
            }
        }
    }
}
