package Processors;
import Nodes.MerpNode;
import Util.*;
import java.util.ArrayList;
import Nodes.*;

/**
 * Created by Varnit Tewari on 2/28/2017.
 */
public class EquationProcessor {
    /**
     * the type of processor
     */
    MerpProcessor processor;
    /**
     * the list of symboltables
     */
    SymbolTable symbolTable;
    /**
     * the arrays list of equations
     */
    java.util.ArrayList<java.lang.String> equations;

    /**
     * constructor
     * @param equations list pf equations
     * @param processor type of processir
     */
    public EquationProcessor(java.util.ArrayList<java.lang.String> equations, MerpProcessor processor){
        this.equations=equations;
        this.processor=processor;
        symbolTable=new SymbolTable();
    }

    /**
     * processing the equations
     */
    public void processEquations(){
        for (String i:equations){
            i = i.trim();
            if (i.startsWith("while")){
                int para=i.indexOf("(");
                int paraend=i.lastIndexOf(")");
                i=i.substring(para+1,paraend);
                String[] Partlist=i.split(",");
                String[] statements=Partlist[1].split(";");
                String cond=Partlist[0];
                String[] condtokens=cond.split(" ");
                ArrayList<String> tokens4=new ArrayList<>();
                for (String k:condtokens){
                    tokens4.add(k);
                }
                processor.constructTree(tokens4);
                MerpNode tree1=processor.getTree();
                while (tree1.evaluate(symbolTable)!=0){
                    for (String a:statements){
                        processEquation(a);
                }
                }
            }else if (i.startsWith("if")){
                int para=i.indexOf("(");
                int paraend=i.lastIndexOf(")");
                i=i.substring(para+1,paraend);
                String[] iflist=i.split(",");
                String cond1=iflist[0];
                String[] condtokens1=cond1.split(" ");
                ArrayList<String> tokens5=new ArrayList<String>();
                for (String k:condtokens1){
                    tokens5.add(k);
                }
                processor.constructTree(tokens5);
                MerpNode tree2=processor.getTree();
                if (tree2.evaluate(symbolTable)!=0){
                    processEquation(iflist[1]);
                }else{
                    processEquation(iflist[2]);
                }
            }
            else{
                processEquation(i);
            }
        }
    }

    /**
     * helper method for processing the equations
     * @param eq one equation passed
     */
    private void processEquation(java.lang.String eq){
        eq = eq.trim();
        if (eq.startsWith("printVar")){
            symbolTable.dump();
        }else if (eq.startsWith("print")){
            int para=eq.indexOf("(");
            int paraend=eq.indexOf(")");
            eq=eq.substring(para+1,paraend);
            java.util.ArrayList<java.lang.String> tokens7=new java.util.ArrayList<java.lang.String>();
            java.lang.String[] tokens8=eq.split(" ");
            for (String j:tokens8){
                tokens7.add(j);
            }
            processor.constructTree(tokens7);
            MerpNode tree5=processor.getTree();
            System.out.println("the value of the expression is = "+tree5.evaluate(symbolTable));
        }else if (eq.substring(0,1).matches( "^[a-zA-Z].*" ) && eq.substring(1,4).equals(" = ")){
            String var= eq.substring(0,1);
            eq=eq.substring(4);
            java.util.ArrayList<java.lang.String> tokens7=new java.util.ArrayList<java.lang.String>();
            java.lang.String[] tokens8=eq.split(" ");
            for (String j:tokens8){
                tokens7.add(j);
            }
            processor.constructTree(tokens7);
            MerpNode tree5=processor.getTree();
            symbolTable.put(var,tree5.evaluate(symbolTable));
        }else{
            eq.trim();
            java.util.ArrayList<java.lang.String> tokens1=new java.util.ArrayList<java.lang.String>();
            java.lang.String[] tokens2=eq.split(" ");
            for (String j:tokens2){
                tokens1.add(j);
            }
            processor.constructTree(tokens1);
            MerpNode tree=processor.getTree();
            tree.evaluate(symbolTable);
        }

    }
}
