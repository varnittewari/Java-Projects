/**
 * Created by varni on 2/24/2017.
 */
import java.util.HashMap;
import java.util.Collection;

public class CourseDB implements DB<Integer,Course>{
    /**
     * course storage
     */
    private HashMap<Integer,Course> courses;

    /**
     * Create the course database.
     */
    public CourseDB(){
        courses= new HashMap();
    }

    /**
     * Add a value entry to the database in constant time
     * @param course course to be added
     * @return previous value
     */
    public Course addValue(Course course){
        Course val99=courses.get(course.getId());
        courses.put(course.getId(),course);
        return val99;
    }

    /**
     * Get all the values in the database in linear time.
     * @param id id
     * @return course
     */
    public Course getValue(Integer id){
        return courses.get(id);
    }

    /**
     * checks if it has the key or not
     * @param id
     * @return boolean
     */
    public boolean hasKey(Integer id){
        return courses.containsKey(id);
    }

    /**
     * gets the values
     * @return collection
     */
    public Collection<Course> getAllValues(){
        return courses.values();
    }
}
