/**
 * Created by Varnit Tewari on 2/18/2017.
 */
public class Appliance extends Component {
    /**
     * The required current (in amps) for this Appliance.
     * Indicates if the device is currently in use.
     */
    private int reqCurrent;
    private boolean inUse;

    /**
     * Constructor for the Appliance. Constructor does not check that the source is correct type of Component
     * (must be a Receptacle). This is checked when this element is attempted to be added to the system.
     * Appliance starts out not in use.
     * @param name name of the appliance
     * @param source source component
     * @param reqCurr required current
     */
    public Appliance(String name, MultiComponent source, int reqCurr){
        super(name,source);
        this.reqCurrent=reqCurr;
        this.inUse=false;
    }

    /**
     * Turns this appliance off. Sets boolean inUse flag to false, and sets currCurrent to 0.
     */
    public void reset(){
        inUse=false;
    }

    /**
     * This automatically returns false, as for this simulation, an Appliance can not be the source for any other Component.
     * @param el component to be added
     * @return false
     */
    public boolean add(Component el){
        return false;
    }

    /**
     * Output a string representation for this Appliance, indenting by the given offset
     * @param offset
     */
    protected void display(String offset){
        System.out.println(offset+name);
    }

    /**
     * toggle usage on/off for this Appliance. Calls updateCurrent to handle with appropriate change.
     * @return null if no overload caused. Else returns circuit object that overloaded.
     */
    public void toggleUsage() { //This method needs a lot of work.
        if (!inUse){
            source.updateCurrent(reqCurrent);
            inUse=true;
        }else {
            source.updateCurrent(-reqCurrent);
            inUse=false;
        }
    }

    /**
     * Accessor for whether device is currently in use.
     * @return boolean
     */
    public boolean getInUse(){
        return inUse;
    }


}
