package Processors;
import Nodes.*;
import Util.*;

import java.util.*;

/**
 * Created by Varnit Tewari on 3/6/2017.
 */
public class MerpInfixProcessor extends MerpProcessor {
    /**
     * constructor
     */
    public MerpInfixProcessor(){

    }

    /**
     * constructs the trees
     * @param tokens list of IerpNodes used to create the pares tree
     */
    public void constructTree(java.util.ArrayList<java.lang.String> tokens){
        Stack<MerpNode> st1=new Stack<>();
        Stack<MerpNode> st2=new Stack<>();
        for (String i:tokens){
            if (isNumeric(i)){
                st1.push(createMerpNode(i));
            }else if (isVariable(i)){
                st1.push(createMerpNode(i));
            }else {
                MerpNode mn1=createMerpNode(i);
                if (mn1.getNodeType()== MerpNode.NodeType.UnaryOperation){
                    while (!st2.isEmpty() && st2.peek().getPrecedence()<=mn1.getPrecedence()){
                        st1.push(st2.pop());
                    }st2.push(mn1);
                }else{
                    while (!st2.isEmpty() && st2.peek().getPrecedence()<mn1.getPrecedence()){
                        st1.push(st2.pop());
                    }st2.push(mn1);
                }
            }
        }
        while (st2.size()>0){
            st1.push(st2.pop());
        }

        tree = processStack(st1);
    }

    /**
     * helper methd for making the tree
     * @param stack stack
     * @return tree
     */
    private MerpNode processStack(java.util.Stack<MerpNode> stack){
        MerpNode t=stack.pop();
        if (t instanceof VariableNode || (t instanceof ConstantNode)){
            return t;
        }
        else{
            if (t.getNodeType() == MerpNode.NodeType.UnaryOperation) {
                UnaryOperatorNode tree1= (UnaryOperatorNode) t;
                tree1.setChild(processStack(stack));
                return tree1;
            } else {
                BinaryOperatorNode tree1= (BinaryOperatorNode) t;
                tree1.setRightChild(processStack(stack));
                tree1.setLeftChild(processStack(stack));
                return tree1;
            }
        }
    }
}
