package Nodes;
import Util.*;

import java.util.function.Predicate;

/**
 * Created by Varnit Tewari on 2/28/2017.
 */
public class ConstantNode extends java.lang.Object implements MerpNode{
    /**
     * value of the node
     */
    private int value;

    /**
     * constructor
     * @param value
     */
    public ConstantNode(int value){
        this.value =value;
    }

    /**
     * evaluates the node
     * @param symbolTable the symbol table to use for variable processing
     * @return value
     */
    public int evaluate(SymbolTable symbolTable){
        return this.value;
    }

    /**
     * converts the node into a string
     * @return string
     */
    public java.lang.String toPrefixString() {
        return ""+value;
    }

    /**
     * converts the node into an infix string
     * @return string
     */
    public java.lang.String toInfixString(){
        return ""+value;
    }

    /**
     * converts the nde into a postfix string
     * @return string
     */
    public java.lang.String toPostfixString(){
        return ""+value;
    }

    /**
     * gets the precedence
     * @return int
     */
    public int getPrecedence(){
        return 3;
    }

    /**
     * checks if its an operation or not
     * @return boolean
     */
    public boolean isOperation(){
        return false;
    }

    /**
     * gets the type of th node
     * @return node type
     */
    public MerpNode.NodeType getNodeType(){
        return NodeType.Constant;
    }
}
