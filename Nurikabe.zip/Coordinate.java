/**
 * Author: Varnit Tewari(vxt6823@rit.edu)
 */
public class Coordinate {
    private int a;
    private int b;

    /**
     * constructor for the coordinates
     * @param var1 row
     * @param var2 column
     */
    public Coordinate(int var1, int var2) {
        this.a = var1;
        this.b = var2;
    }

    /**
     * gets the row number
     * @return integer
     */
    public int getRow() {
        return this.a;
    }

    /**
     * gets the column number
     * @return integer
     */
    public int getCol() {
        return this.b;
    }

    /**
     * cjecks if two coordinates are equal or not
     * @param var1 coordinate
     * @return boolean
     */
    public boolean equals(Object var1) {
        if(!(var1 instanceof Coordinate)) {
            return false;
        } else {
            Coordinate var2 = (Coordinate)var1;
            return this.a == var2.a && this.b == var2.b;
        }
    }

    /**
     * returns the hashcode
     * @return integer
     */
    public int hashCode() {
        return this.a * 21 + this.b;
    }

    /**
     * converts it into string
     * @return string
     */
    public String toString() {
        return "(Row: " + this.a + ", Col: " + this.b + ")";
    }
}
