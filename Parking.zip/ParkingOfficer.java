package Lab2;
import Lab2.Vehicle;
import java.util.ArrayList;
import Lab2.ParkingSpot;
import Lab2.ParkingOfficer;

/**
 * Created by Varnit Tewari on 2/6/2017.
 */
public class ParkingOfficer {
    private ParkingLot lot;
    private static int PAUSE_TIME;
    private ArrayList<Ticket> tickets;

    /**
     * Create the parking officer. Initially, there is no lot, and no tickets have been issued yet.
     */
    public ParkingOfficer(){
        lot=null;
        tickets= new ArrayList<Ticket>();
    }

    /**
     * Determine the type of fine a vehicle *would* get if they parked in a spot. If a vehicle is in a handicapped spot and either doesn't have a permit
     * @param vehicle
     * @param spot
     * @return
     */
    public static Fine getFineVehicleSpot(Vehicle vehicle,
                                          ParkingSpot spot){
        if (spot.getType()==Permit.Type.HANDICAPPED){
            if (vehicle.getPermit()==null || vehicle.getPermit().getType()!=Permit.Type.HANDICAPPED){
                return Fine.PARKING_HANDICAPPED;
            }}

        else if(spot.getType()== Permit.Type.RESERVED){
                if (vehicle.getPermit()==null || (vehicle.getPermit().getType()!=Permit.Type.RESERVED || vehicle.getPermit().getType()!=Permit.Type.HANDICAPPED)){
                    return Fine.PARKING_RESERVED;
                }
            }
        else if (spot.getType()== Permit.Type.GENERAL){
            if (vehicle.getPermit()==null){
                return Fine.NO_PERMIT;
            }
            }

            return Fine.NO_FINE;

    }

    /**
     * Connect the parking officer to the parking lot they will be responsible for patrolling.
     * @param lot
     */
    public void setParkingLot(ParkingLot lot){
        this.lot = lot;
    }

    /**
     * get the list of tickets being issued
     * @return
     */
    public ArrayList<Ticket> getTickets(){
        return this.tickets;
    }

    /**
     * Issue a ticket to a vehicle with a fine. If a ticket is issued it should print:
     Issuing ticket to: {vehicle} in spot {spot} for {fine}
     * @param vehicle
     * @param spot
     * @param fine
     */
    private void issueTicket(Vehicle vehicle,
                             int spot,
                             Fine fine){
        Ticket ticket= new Ticket(vehicle.getPlate(),fine);
        vehicle.giveTicket(ticket);
        tickets.add(ticket);
        System.out.println("Issuing ticket to "+vehicle.getPlate()+"in spot "+spot+"for "+fine);
    }

    /**
     * The officer checks all the vehicles if they are to be fined or not
     */
    public void patrolLot(){
        int cap=lot.getCapacity();
        for (int i=0;i<cap;i++){
            ParkingSpot p=lot.getSpot(i);
            Vehicle veh=p.getVehicle();
            if (veh!=null){
                if (getFineVehicleSpot(veh,p)!=Fine.NO_FINE){
                    System.out.println("Fine is"+getFineVehicleSpot(veh,p));
                    issueTicket(veh,i,getFineVehicleSpot(veh,p));
                }else{
                    System.out.println("NO TICKET ISSUED");
                }
            }
        }
    }

    /**
     * tester function for all functions above
     * @param args
     */
    public static void main(String[] args){
       ParkingLot PL1= new ParkingLot(10,10,10);

       Vehicle V1= new Vehicle(123);
       Vehicle V2= new Vehicle(12);
       Vehicle V3= new Vehicle(1234);
       Vehicle V4= new Vehicle(1);
       Vehicle V5= new Vehicle(24443);
       Vehicle V6= new Vehicle(6772);
       Permit P1= new Permit(86328748, Permit.Type.GENERAL);
        Permit P2= new Permit(8632874, Permit.Type.HANDICAPPED);
        Permit P3= new Permit(863288, Permit.Type.RESERVED);
        Permit P4= new Permit(86748, Permit.Type.HANDICAPPED);
        Permit P5= new Permit(8648, Permit.Type.GENERAL);
        Permit P6= new Permit(8628748, Permit.Type.GENERAL);

       V1.setPermit(P1);
        V2.setPermit(P2);
        V3.setPermit(P3);
        V4.setPermit(P4);
        V5.setPermit(P5);
        V6.setPermit(P6);

        PL1.parkVehicle(V1,0);
        PL1.parkVehicle(V2,1);
        PL1.parkVehicle(V3,2);
        PL1.parkVehicle(V4,3);
        PL1.parkVehicle(V5,4);

        ParkingOfficer PO= new ParkingOfficer();
        PO.setParkingLot(PL1);
        PO.patrolLot();
    }
}
