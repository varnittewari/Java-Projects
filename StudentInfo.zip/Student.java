/**
 * Created by varni on 2/24/2017.
 */
public class Student extends User {

    public Student(String username){
        /**
         * creae a new student
         */
        super(username,UserType.STUDENT,Course::compareTo);
    }
}
