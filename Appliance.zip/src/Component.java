
/**
 * Created by Varnit Tewari on 2/18/2017.
 */
public abstract class Component {
    /**
     * source of this component.
     * name associated with this component.
     */

    protected MultiComponent source;
    protected String name;

    /**
     * Basic constructor for an electrical Component involves a name and a source. All objects have a source in the
     * system except for the root circuit. Current is always initialized to 0.
     * @param name name of the component
     * @param source component it is connected to
     */
    protected Component(String name, MultiComponent source){
        this.name=name;
        this.source=source;
    }

    /**
     * to add the component
     * @param newElem component to be added
     * @return boolean
     */
    public abstract boolean add(Component newElem);

    /**
     * Reset this object along with all of its children. This involves turning off all descendant Appliances so that
     * they are not drawing any current.
     */
    public abstract void reset();

    /**
     * Output a string representation of the given electrical Component and its children.
     * @param offset
     */
    protected abstract void display(String offset);

    /**
     * Output a string representation of this Component and its children. The public method is called without any parameter.
     * This method needs only call the protected version of the method with an initial offset that is the empty string.
     */
    public void display(){
        display("");
    }

    public String getName(){
        return name;
    }

}
