/**
 * Created by varni on 2/24/2017.
 */
import java.util.Collection;
public interface DB<K,V>{
    /**
     * Add a value entry to the database in constant time.
     * @param value value
     * @return value
     */
    V addValue(V value);

    /**
     *Get the value for an associated key in constant time.
     * @param key for the value to be found
     * @return V
     */
    V getValue(K key);

    /**
     * Indicates whether a key is in the database or not, in constant time.
     * @param key for the value to be found
     * @return boolean
     */
    boolean hasKey(K key);

    /**
     * Get all the values in the database in linear time.
     * @return collection
     */
    Collection<V> getAllValues();
}
