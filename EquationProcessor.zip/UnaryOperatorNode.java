package Nodes;

/**
 * Created by varni on 2/28/2017.
 */
public abstract class UnaryOperatorNode
        extends java.lang.Object
        implements MerpNode {
    /**
     * child
     */
    protected MerpNode child;
    /**
     * operator or the parent
     */
    protected java.lang.String operator;
    /**
     * precedence
     */
    protected Precedence precedence;

    /**
     * constructor
     * @param child child
     * @param precedence precedence
     * @param operator operator
     */
    public UnaryOperatorNode(MerpNode child,
                             Precedence precedence,
                             java.lang.String operator){
        this.child=child;
        this.precedence=precedence;
        this.operator=operator;
    }

    /**
     * sets the child
     * @param child child
     */
    public void setChild(MerpNode child){
        this.child=child;
    }

    /**
     * to prefix string
     * @return string
     */
    public java.lang.String toPrefixString() {
       return operator+" "+child.toPrefixString();
    }

    /**
     * to infix string
     * @return string
     */
    public java.lang.String toInfixString(){
        return "("+operator+" "+child.toInfixString()+")";
    }

    /**
     * to postfix string
     * @return string
     */
    public java.lang.String toPostfixString(){
        return child.toPostfixString()+" "+operator;
    }

    /**
     * gets the precedence
     * @return int
     */
    public int getPrecedence(){
        return this.precedence.getPrecedence();
    }

    /**
     * checks if its an operation or not
     * @return
     */
    public boolean isOperation(){
        if (child instanceof VariableNode){
            return false;
        }
        return true;
    }

    /**
     * gets the type of node
     * @return node type
     */
    public MerpNode.NodeType getNodeType(){
        return MerpNode.NodeType.UnaryOperation;
    }
}
