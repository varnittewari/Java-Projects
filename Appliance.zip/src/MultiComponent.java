/**
 * Created by Varnit Tewari on 2/18/2017.
 */
import java.util.ArrayList;
public abstract class MultiComponent extends Component {
    /**
     * list of all children connected to this Component
     */
    protected int currCurrent;
    protected ArrayList<Component> children;

    /**
     * Basic constructor for MultiComponent object. Calls parent constructor, and also initializes a list of children objects.
     * @param name name of the component
     * @param source component it is connected to
     */
    protected MultiComponent(String name, MultiComponent source){ //This constructor doesn't work.
        super(name,source);
        children= new ArrayList<Component>();
    }

    /**
     * Reset this MultiComponent to have a current usage of 0, and call reset on all children.
     */
    public void reset(){
        currCurrent=0;
    }

    /**
     * updates the current
     * @param deltaCurrent
     */
    protected abstract void updateCurrent(int deltaCurrent);
}
