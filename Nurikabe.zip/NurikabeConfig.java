import com.sun.xml.internal.bind.v2.runtime.Coordinator;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

/**
 * A class to represent a single configuration in the Nurikabe puzzle.
 *
 * @author Sean Strout @ RITCS
 * @author Varnit Tewari
 */
public class NurikabeConfig implements Configuration {

    // TODO
    private Coordinate cursor;
    private String[][] board;

    /**
     * Construct the initial configuration from an input file whose contents
     * are, for example:<br>
     * <tt><br>
     * 3 3          # rows columns<br>
     * 1 . #        # row 1, .=empty, 1-9=numbered island, #=island, &#64;=sea<br>
     * &#64; . 3    # row 2<br>
     * 1 . .        # row 3<br>
     * </tt><br>
     * @param filename the name of the file to read from
     * @throws FileNotFoundException if the file is not found
     */
    public NurikabeConfig(String filename) throws FileNotFoundException {
        try (Scanner in = new Scanner(new File(filename))) {
            // TODO
            String line;
            line=in.nextLine();
            String[] sc=line.split(" ");
            if (sc.length==2){
                board= new String[Integer.parseInt(sc[0])][Integer.parseInt(sc[1])];
            }
            for (int i=0;i<Integer.parseInt(sc[0]);i++){
                String line1=in.nextLine();
                String sc1[]=line1.split(" ");
                for (int j=0;j<Integer.parseInt(sc[1]);j++){
                    board[i][j]=sc1[j];
                }
            }
        }
        cursor= curvalue();
    }

    /**
     * The copy constructor takes a config, other, and makes a full "deep" copy
     * of its instance data.
     *
     * @param other the config to copy
     */
    protected NurikabeConfig(NurikabeConfig other) {
        // TODO
        String[][] copboard =new String[other.board.length][other.board[0].length];
        for (int i=0;i<other.board.length;i++){
            for (int j=0;j<other.board[i].length;j++){
                copboard[i][j]=other.board[i][j];
            }
        }
        board = copboard;
        Coordinate curr=curvalue();
        cursor=curr;
    }

    /**
     * its the DFS function that checks if the islands are connected together or not, also searches for islands.
     * @param curr coordinate of the cursor
     * @param visited list of visited islands
     * @return list of all coordinates of  visited islands
     */
    public ArrayList<Coordinate> buildpath(Coordinate curr,ArrayList<Coordinate> visited){
        LinkedList<Coordinate> toSearch=new LinkedList<>();
        toSearch.add(curr);
        while(toSearch.size()!=0){
            Coordinate removedCoor=toSearch.remove(0);
            visited.add(removedCoor);
            for (Coordinate c:addneighbour(removedCoor)){
                if (!board[c.getRow()][c.getCol()].equals("@") && !board[c.getRow()][c.getCol()].equals(".")){
                    if (!(toSearch.contains(c) || visited.contains(c))){
                        toSearch.add(c);
                    }
                }
            }
        }
        return visited;
    }

    /**
     * its the DFS function to check if all the seas are connected or not. It is only called when the board is full
     * @param curr coordinates of the current sea
     * @param visited list of coordinates of all seas
     * @return visited
     */
    public HashSet<Coordinate> buildpath1(Coordinate curr,HashSet<Coordinate> visited){
        LinkedList<Coordinate> toSearch=new LinkedList<>();
        toSearch.add(curr);
        while(toSearch.size()!=0){
            Coordinate removedCoor=toSearch.remove(0);
            visited.add(removedCoor);
            for (Coordinate c:addneighbour(removedCoor)){
                if (board[c.getRow()][c.getCol()].equals("@")){
                    if (!(toSearch.contains(c) || visited.contains(c))){
                        toSearch.add(c);
                    }
                }
            }
        }
        return visited;
    }

    /**
     * it gives the number of seas
     * @return integer
     */
    public int numSeas(){
        int c=0;
        for (int i=0;i<board.length;i++){
            for (int j=0;j<board[0].length;j++){
                if (board[i][j].equals("@")){
                    c++;
                }
            }
        }
        return c;
    }

    /**
     * assigns the cursor to the coordinate where there is a dot on the board
     * @return coordinate of the dot
     */
    public Coordinate curvalue(){
        for (int i=0;i<board.length;i++){
            for (int j=0;j<board[0].length;j++){
                if (board[i][j].equals(".")){
                    cursor= new Coordinate(i,j);
                    return cursor;
                }
            }
        }
        return cursor;
    }

    /**
     * Get the collection of successors from the current one. It gets all the possibilities.
     * @return list of successors
     */
    @Override
    public Collection<Configuration> getSuccessors() {
        // TODO
        LinkedList<Configuration> succ=new LinkedList<>();
               if (!(board[cursor.getRow()][cursor.getCol()].equals("."))){
                   cursor=curvalue();
               }
                   NurikabeConfig copynurikabe=new NurikabeConfig(this);
                   int r=copynurikabe.cursor.getRow();
                   int c=copynurikabe.cursor.getCol();
                   copynurikabe.board[r][c]="#";
                   succ.add(copynurikabe);
                   NurikabeConfig copynurikabe1=new NurikabeConfig(this);
                   copynurikabe1.board[r][c]="@";
                   succ.add(copynurikabe1);
       return succ;
    }

    /**
     * it is a helped function to add neighours of a specific coordinate to a list that is used many times.
     * @param c coordinate of the centre of neighbours
     * @return list of neighbours
     */
    public LinkedList<Coordinate> addneighbour(Coordinate c){
        LinkedList< Coordinate> neighbours=new LinkedList<>();
        if (c.getRow()<board.length-1) {
            neighbours.add(new Coordinate(c.getRow() + 1, c.getCol()));
        }
        if (c.getRow()>0) {
            neighbours.add(new Coordinate(c.getRow() - 1, c.getCol()));
        }
        if (c.getCol()<board[0].length-1) {
            neighbours.add(new Coordinate(c.getRow(), c.getCol() + 1));
        }
        if (c.getCol()>0) {
            neighbours.add(new Coordinate(c.getRow(), c.getCol() - 1));
        }
        return neighbours;
    }

    /**
     * it is helped function that checks all the possibilities of board going invalid .
     * @param curr coordinates of the cursor to check its neighbours and itself if its valid or not
     * @return boolean
     */
    public boolean validate(Coordinate curr){
        if(board[curr.getRow()][curr.getCol()].equals("#")) {
            LinkedList<Coordinate> toSearch = new LinkedList<>();
            LinkedList<Coordinate> visited = new LinkedList<>();
            toSearch.add(curr);
            while (toSearch.size() != 0) {
                Coordinate removedCoor = toSearch.remove(0);
                visited.add(removedCoor);
                for (Coordinate c : addneighbour(removedCoor)) {
                    if (board[c.getRow()][c.getCol()].equals("#")) {
                        if (!(toSearch.contains(c) || visited.contains(c))) {
                            toSearch.add(c);
                        }
                    }
                    else if (board[c.getRow()][c.getCol()].equals("@")) {
                        continue;
                    }
                    else if (board[c.getRow()][c.getCol()].equals(".")) {
                        return true;
                    }
                    else{
                        return true;
                    }
                }
            }
            return false;
        }
        else if(board[curr.getRow()][curr.getCol()].equals("@")) {
            boolean has_sea = false;
            for (Coordinate seaneighbour : addneighbour(curr)) {
                if (board[seaneighbour.getRow()][seaneighbour.getCol()].equals(".") ||
                        board[seaneighbour.getRow()][seaneighbour.getCol()].equals("@")) {
                    has_sea = true;
                }
            }
            if (curr.getRow() > 0 && curr.getCol() > 0) {
                if (board[curr.getRow() - 1][curr.getCol() - 1].equals("@") && board[curr.getRow()][curr.getCol() - 1].equals("@") &&
                        board[curr.getRow() - 1][curr.getCol()].equals("@")) {
                    return false;
                }
            }
            return has_sea;
        }
        else if(board[curr.getRow()][curr.getCol()].equals(".")){
            return true;
        }
        else{
            ArrayList<Coordinate> islands = new ArrayList<>();
            int count = 0;
            int count1 = 0;
            islands = buildpath(curr, islands);
            for (Coordinate s : islands) {
                if (!(board[s.getRow()][s.getCol()].equals("#")) && !(board[s.getRow()][s.getCol()].equals("."))) {
                    count++;
                    count1 = Integer.parseInt(board[s.getRow()][s.getCol()]);
                }
            }
            boolean canexpand=false;
            for (Coordinate island:islands){
                for (Coordinate islneighbours:addneighbour(island)){
                    if (board[islneighbours.getRow()][islneighbours.getCol()].equals(".")){
                        canexpand=true;
                        break;
                    }
                }
                break;
            }
            if ((count == 1 && count1 > islands.size()) && canexpand) {
                return true;
            }
            if (count!=1 || count1 < islands.size()){
                return false;
            }
            if(count == 1 && count1 == islands.size()){
                return true;
            }
        }
        return true;
    }

    /**
     * Is the current configuration valid or not? it does many checks and calls validate
     * @return boolean
     */
    @Override
    public boolean isValid() {
        boolean flag=true;
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[0].length; j++) {
                if (board[i][j].equals(".")) {
                    flag = false;
                }
            }
        }
        boolean valid_neighbors = true;
        boolean all_clear = false;
        if(validate(cursor)) {
            for (Coordinate validneighbour : addneighbour(cursor)) {
                if (!validate(validneighbour)) {
                    valid_neighbors = false;
                    break;
                }
            }
            if(valid_neighbors){
                all_clear = true;
            }
        }
        if (flag){
            HashSet<Coordinate> seas = new HashSet<>();
            Coordinate hold_curr = new Coordinate(cursor.getRow(), cursor.getCol());
            for (int i=0;i<board.length;i++){
                for (int j=0;j<board[0].length;j++){
                    if (board[i][j].equals("@")){
                        cursor= new Coordinate(i,j);
                        break;
                    }
                }
            }
            seas = buildpath1(cursor,seas);
            if (numSeas()!=seas.size()){
                cursor = new Coordinate(hold_curr.getRow(), hold_curr.getCol());
                return false;
            }
            for (int i = 0; i < board.length; i++) {
                for (int j = 0; j < board[0].length; j++) {
                    if (!board[i][j].equals(".") && !board[i][j].equals("#") && !board[i][j].equals("@")) {
                       if(!validate(new Coordinate(i,j))){
                           return false;
                        }
                    }
                }
            }
        }
        return all_clear;
    }

    /**
     * Is the current configuration a goal?
     * @return boolean
     */
    @Override
    public boolean isGoal() {
        // TODO
        boolean flag=true;
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[0].length; j++) {
                if (board[i][j].equals(".")) {
                    flag = false;
                }
            }
        }
        for (int i=0;i<board.length;i++){
            for (int j=0;j<board[0].length;j++){
                if (board[i][j].equals("@")){
                    cursor= new Coordinate(i,j);
                    break;
                }
            }
        }
        if (flag){
            HashSet<Coordinate> seas = new HashSet<>();
            seas = buildpath1(cursor,seas);
            if (numSeas()!=seas.size()){
                return false;
            }
            return isValid();
        }
        return false;
    }

    /**
     * Returns a string representation of the puzzle, e.g.: <br>
     * <tt><br>
     * 1 . #<br>
     * &#64; . 3<br>
     * 1 . .<br>
     * </tt><br>
     */
    @Override
    public String toString() {
        String result = "";
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[i].length; j++) {
                result = result + board[i][j]+" ";
            }
            result += "\n";
        }
        return result;
    }
}
