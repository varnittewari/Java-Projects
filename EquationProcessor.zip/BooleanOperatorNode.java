package Nodes;

/**
 * Created by Varnit Tewari on 2/28/2017.
 */
public abstract class BooleanOperatorNode extends BinaryOperatorNode {
    /**
     * Constructor for Boolean operation nodes The precedence is set to BOOLEAN
     * @param left
     * @param right
     * @param operator
     */
    public BooleanOperatorNode(MerpNode left, MerpNode right, java.lang.String operator){
        super(left,right,Precedence.BOOLEAN,operator);
    }

    /**
     *gets the precedence
     * @return precedence
     */
    public int getPrecedence(){
        return this.precedence.getPrecedence();
    }
}
