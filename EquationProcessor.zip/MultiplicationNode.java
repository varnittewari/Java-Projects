package Nodes;
import Util.*;

/**
 * Created by Varnit Tewari on 2/28/2017.
 */
public class MultiplicationNode extends BinaryOperatorNode {
    /**
     * constructor
     * @param left child
     * @param right child
     */
    public MultiplicationNode(MerpNode left, MerpNode right){
        super(left,right,Precedence.MULT_DIVIDE,"*");
    }
    /**
     * evaluates the node
     * @param symbolTable the symbol table to use for variable processing
     * @return int
     */
    public int evaluate(SymbolTable symbolTable){
        return leftChild.evaluate(symbolTable)* rightChild.evaluate(symbolTable);
    }
}
