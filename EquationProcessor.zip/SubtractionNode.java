package Nodes;
import Util.*;

/**
 * Created by Varnit Tewari on 2/28/2017.
 */

public class SubtractionNode extends BinaryOperatorNode {
    /**
     * constructor
     * @param left child
     * @param right child
     */
    public SubtractionNode(MerpNode left, MerpNode right){
        super(left,right,Precedence.ADD_SUBTRACT,"-");
    }
    /**
     * evaluates the node
     * @param symbolTable the symbol table to use for variable processing
     * @return int
     */
    public int evaluate(SymbolTable symbolTable) {
        return leftChild.evaluate(symbolTable)- rightChild.evaluate(symbolTable);
    }
}
