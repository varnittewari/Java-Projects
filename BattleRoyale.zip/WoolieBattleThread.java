import java.util.ArrayList;

/**
 * Created by varni on 4/26/2017.
 */
public class WoolieBattleThread extends Thread {
    /**
     * fighter 1
     */
    private Woolie fighter1;
    /**
     * woolie who is the opponent
     */
    private Woolie fighter2;
    /**
     * sportcomplex in which they fight
     */
    SportsComplex sc;
    /**
     * winner of the fight
     */
    Woolie winner;

    /**
     * WoolieBattleThread constructor
     * @param fighter1 fighter 1
     * @param fighter2 fighter 2
     * @param sportsComplex arena
     */
    public WoolieBattleThread(Woolie fighter1,
                              Woolie fighter2,
                              SportsComplex sportsComplex){
        this.fighter1=fighter1;
        this.fighter2=fighter2;
        this.sc=sportsComplex;
    }

    /**
     * gets the first fighter
     * @return
     */
    public Woolie getFighter1(){
        return this.fighter1;
    }

    /**
     * gets ythe second fighter
     * @return
     */
    public Woolie getFighter2(){
        return this.fighter2;
    }

    /**
     * main function to run and fight the battle
     */
    public void run(){
        enterArena();
        int t=0;
        System.out.println("Woolies: "+getFighter1().getName()+" and "+getFighter2().getName()+" enter arena to battle");
        System.out.println("The battle has begun between " +fighter1.getName()+" and "+ fighter2.getName());
        while( fighter1.isOK() && fighter2.isOK()){
            if (t%fighter1.getAttackAmount()==0){
                fighter2.takeDamage(fighter1.getAttackAmount());
                System.out.println(fighter1.getName()+" does "+ String.valueOf(fighter1.getAttackAmount())+ " damage to "+ fighter2.getName());
                System.out.println(fighter2.getName()+" has "+ fighter2.getCurrentHP()+" left.");
                System.out.println();
                if (!fighter2.isOK()){
                    winner=fighter1;
                }
            }
            if (t%fighter2.getAttackAmount()==0) {
                fighter1.takeDamage(fighter2.getAttackAmount());
                System.out.println(fighter2.getName()+" does "+ String.valueOf(fighter2.getAttackAmount())+ " damage to "+ fighter1.getName());
                System.out.println(fighter1.getName()+" has "+ fighter1.getCurrentHP()+" left.");
                System.out.println();
                if (fighter1.isOK()) {
                    winner = fighter2;
                }
            }
            t++;
        }
        System.out.println("The battle is over");
        System.out.println(winner.getName()+ " is the winner");
        winner.reset();
        exitArena();
    }

    /**
     * gets the winner
     * @return woolie
     */
    public Woolie getWinner(){
        return this.winner;
    }

    /**
     * enters the arena
     */
    public void enterArena(){
        System.out.println("Woolies: "+fighter1.getName()+" and "+ fighter2.getName()+" enter arena line to battle");
        sc.enterArena(this);
    }

    /**
     * fighters exit the arena
     */
    public void exitArena(){
        System.out.println("Woolie: "+winner.getName()+" leaves the arena victorious");
        sc.leaveArena();
    }

}
