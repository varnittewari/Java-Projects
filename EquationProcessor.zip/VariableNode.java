package Nodes;
import Util.*;

/**
 * Created by Varnit Tewari on 2/28/2017.
 */
public class VariableNode extends java.lang.Object implements MerpNode {
    /**
     * the name of the variable
     */
    private java.lang.String name;

    /**
     * constructor
     * @param name
     */
    public VariableNode(java.lang.String name){
        this.name=name;
    }

    /**
     * evaluates the node
     * @param symbolTable the symbol table to use for variable processing
     * @return int
     */
    public int evaluate(SymbolTable symbolTable){
       return  symbolTable.get(name);
    }

    /**
     *  to prefix string
     * @return string
     */
    public java.lang.String toPrefixString(){
        return name;
    }

    /**
     * to infix string
     * @return string
     */
    public java.lang.String toInfixString(){
        return name;
    }

    /**
     * to postfix string
     * @return string
     */
    public java.lang.String toPostfixString(){
        return name;
    }

    /**
     * gets the precedence
     * @return int
     */
    public int getPrecedence(){
        return 3;
    }

    /**
     * checks if its an operation or not
     * @return boolean
     */
    public boolean isOperation(){
        return false;
    }

    /**
     * gets the type of node
     * @return ode type
     */
    public MerpNode.NodeType getNodeType(){
        return NodeType.Variable;
    }
}
