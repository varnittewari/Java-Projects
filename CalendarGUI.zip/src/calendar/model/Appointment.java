package calendar.model;

/**
 * Created by Varnit Tewari on 4/12/2017.
 */
public class Appointment implements Comparable<Appointment> {
/**
date of the appointment
 */
    private int date;
    /**
     * time of the appointment
     */
    private Time time;
    /**
     * desscription of the appointment
     */
    private String what;

    /**
     * constructor
     * @param date date
     * @param time time
     * @param what description
     */
    public Appointment(int date,
                       Time time,
                       String what){
        this.date=date;
        this.time=time;
        this.what=what;
    }

    /**
     * gets the time
     * @return time
     */
    public Time getTime(){
        return time;
    }

    /**
     * gets the date
     * @return int
     */
    public int getDate(){
        return date;
    }

    /**
     * gets the description
     * @return string
     */
    public String getText(){
        return what;
    }

    /**
     * taes the input and makes an appointment
     * @param inputLine string line
     * @return an appointment
     */
    public static Appointment fromString(String inputLine){
        if (inputLine.length()!=1){
            String[] data=inputLine.split(",");
            int newDate=Integer.parseInt(data[0]);
            String[] timings=data[1].split(":");
            int hr=Integer.parseInt(timings[0]);
            int min=Integer.parseInt(timings[1]);
            Time newTime=new Time(hr,min);
            Appointment newApp=new Appointment(newDate,newTime,data[2]);
            return newApp;
        }
        else{
            return null;
        }
    }

    /**
     * converts the appointment to a string
     * @return String
     */
    @Override
    public String toString() {
        return "on "+this.date+" at "+this.time+" -- "+this.what;
    }

    /**
     * writes the appointment in csv format
     * @return String
     */
    public String csvFormat(){
        return String.valueOf(date)+","+String.valueOf(getTime())+","+what;
    }

    /**
     * compares two appointments on the basis of their dates
     * @param other appointment
     * @return int
     */
    public int compareTo(Appointment other) {

        int result=this.date-other.getDate();
        if (result==0){
            return this.time.compareTo(other.getTime());
        }
        return result;
    }

    /**
     * checks if two appointments are equal or not
     * @param other appointment
     * @return bolean
     */
    public boolean equals(Object other){
        if (other instanceof Appointment){
            Appointment a=(Appointment) other;
            return this.time.compareTo(a.getTime())==0 && this.date==a.getDate();
        }
        return false;
    }
}
