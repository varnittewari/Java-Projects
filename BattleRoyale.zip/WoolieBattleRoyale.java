import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Created by Varnit Tewari on 4/26/2017.
 */
public class WoolieBattleRoyale {
    /**
     * constructor for this class
     */
    public WoolieBattleRoyale(){

    }

    /**
     * takes input from the file and does everything
     * @param args filename
     * @throws FileNotFoundException
     */
    public static void main(String[] args) throws FileNotFoundException {
        ArrayList<Woolie> lst=new ArrayList<>();
        int numArenas=0;
        Scanner sc=new Scanner(new File(args[0]));
        String arenas = sc.nextLine();
        numArenas=Integer.parseInt(arenas);
        while (sc.hasNextLine()) {
            String line = sc.nextLine();
                String[] args1 = line.split(",");
                Woolie w=new Woolie(args1);
                lst.add(w);

        }
        SportsComplex arena=new SportsComplex(numArenas);
        Troll tr=new Troll(lst,arena);
        tr.beginBattleRoyale();
    }
}
