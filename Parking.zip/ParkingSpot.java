package Lab2;

/**
 * Created by Varnit Tewari on 2/4/2017.
 */
public class ParkingSpot {

    private static String OCCUPIED_STR = "*";
    private int spot;
    private Permit.Type type;
    private Vehicle vehicle;

    /**
     * Create a new parking spot.
     * @param spot
     * @param type
     */
    public ParkingSpot(int spot, Permit.Type type){
        this.spot=spot;
        this.type=type;
        this.vehicle=null;
    }

    /**
     * gets the spot
     * @return
     */
    public int getSpot(){
        return this.spot;
    }

    /**
     * gets the type of the permit
     * @return
     */
    public Permit.Type getType(){
        return this.type;
    }

    /**
     * gets the vehicle
     * @return
     */
    public Vehicle getVehicle(){
            return this.vehicle;
    }

    /**
     * The main test function for the ParkingSpot class.
     * @param args
     */
    public static void main(String args[]){
        ParkingSpot ps1= new ParkingSpot(1, Permit.Type.HANDICAPPED);
        System.out.println("The spot is 1?"+(1==ps1.getSpot()?"Yes":"NO, got:"+ps1.getSpot()));
        System.out.println("The permit type is Handicapped?"+(Permit.Type.HANDICAPPED==ps1.getType()?"YES":"NO,GOT:"+ps1.getType()));
        System.out.println("The vehicle is null"+ (ps1.getVehicle()==null ? "YES":"NO"));
        Vehicle v1= new Vehicle(12456);
        ps1.occupySpot(v1);
        verifySpot("*",ps1,1, Permit.Type.HANDICAPPED,v1);
        ps1.vacateSpot();
        System.out.println("Successfully vacated?");
        verifySpot("H",ps1,1, Permit.Type.HANDICAPPED,v1);

        ParkingSpot ps2= new ParkingSpot(10, Permit.Type.RESERVED);
        System.out.println("The spot is 10?"+(10==ps2.getSpot()?"Yes":"NO, got:"+ps2.getSpot()));
        System.out.println("The permit type is Reserved?"+(Permit.Type.RESERVED==ps2.getType()?"YES":"NO,GOT:"+ps2.getType()));
        Vehicle v2= new Vehicle(1237876782);
        System.out.println("The vehicle is "+ v2.toString());
        ps2.occupySpot(v2);
        verifySpot("*",ps2,10, Permit.Type.HANDICAPPED,v2);

        ParkingSpot ps3= new ParkingSpot(10, Permit.Type.RESERVED);
        verifySpot("*",ps3,10, Permit.Type.RESERVED,v2);
    }

    /**
     * occupies the spot
     * @param vehicle
     */
    public void occupySpot(Vehicle vehicle){
        this.vehicle=vehicle;
        vehicle.setParked(true);
    }

    /**
     * converts the parking spot object to a string
     * @return
     */
    public String toString() {
        if (vehicle != null) {
            return ( spot + ":"+OCCUPIED_STR);
        } else {
            if (type == Permit.Type.HANDICAPPED) {
                return (spot + ":H");
            } else if (type == Permit.Type.RESERVED) {
                return (spot + ":R");
            } else {
                return (spot + ":G");
            }
        }
    }

    /**
     * vacates the spot
     */
    public void vacateSpot(){
        vehicle.setParked(false);
        vehicle=null;
    }

    /**
     * Verify a parking spot has the correct spot id, type and vehicle.
     * @param spotVar
     * @param s
     * @param spot
     * @param type
     * @param vehicle
     */
    private static void verifySpot(String spotVar, ParkingSpot s, int spot, Permit.Type type, Vehicle vehicle){
        System.out.println((s.spot==spot)?"Match":"Unmatch");
        System.out.println((s.type==type)?"Match":"Unmatch");
        if (vehicle!=null || s.vehicle!=null){
            System.out.println((vehicle==s.vehicle)?"There is a vehicle that matches":"There is a vehicle but does not match");
        }
        System.out.println(vehicle.toString());
    }

}
