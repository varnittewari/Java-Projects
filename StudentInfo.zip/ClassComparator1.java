import java.util.Comparator;
/**
 * Created by varnit tewari on 3/7/2017.
 */

/**
 * comparing class for professor
 */
public class ClassComparator1 implements Comparator<Course> {
    /**
     * comparing method for professor
     * @param o1 bject 1
     * @param o2 object 2
     * @return integer -1,0,1
     */
    public int compare(Course o1,Course o2){
        int result=o1.getLevel()-o2.getLevel();
        if (result==0){
            return o1.getName().compareTo(o2.getName());
        }
        return result;
    }
}
