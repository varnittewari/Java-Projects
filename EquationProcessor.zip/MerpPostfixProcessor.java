package Processors;
import Nodes.*;

/**
 * Created by Varnit Tewari on 3/6/2017.
 */
public class MerpPostfixProcessor extends MerpProcessor{
    /**
     * constructor
     */
    public MerpPostfixProcessor(){}
    /**
     * constructs the trees
     * @param tokens list of IerpNodes used to create the pares tree
     */
    public void constructTree(java.util.ArrayList<java.lang.String> tokens){
        tree = constructTreeHelper(tokens);
    }
    /**
     * helper methd for making the tree
     * @param tokens array list of tokens
     * @return tree
     */
    private MerpNode constructTreeHelper(java.util.ArrayList<java.lang.String> tokens){
        String c=tokens.get(tokens.size()-1);
        MerpNode t=createMerpNode(c);
        tokens.remove(tokens.size()-1);
        if (isVariable(c) || (isNumeric(c))){
            return t;
        }
        else{
            if (t.getNodeType() == MerpNode.NodeType.UnaryOperation) {
                UnaryOperatorNode tree1= (UnaryOperatorNode) t;
                tree1.setChild(constructTreeHelper(tokens));
                return tree1;
            } else {
                BinaryOperatorNode tree1= (BinaryOperatorNode) t;
                tree1.setRightChild(constructTreeHelper(tokens));
                tree1.setLeftChild(constructTreeHelper(tokens));
                return tree1;
            }
        }
    }
}

/*
Prefix: + 3 3
Postfix: 3 3 +

Prefix: > | 3 - 1 1
Postfix: 1 1 - 3 | >

Prefix: ^ ^ 2 2 + 2 2
Postfix: 2 2 + 2 2 ^ ^
 */