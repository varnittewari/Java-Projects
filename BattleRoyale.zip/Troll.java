import java.util.ArrayList;
import java.util.Random;

/**
 * Created by Varnit Tewari on 4/26/2017.
 */
public class Troll {
    /**
     *
     */
    public static int seed;
    /**
     * list of woolies in the competition
     */
    private ArrayList<Woolie> woolies;
    /**
     * the battle arenas
     */
    private SportsComplex sportsComplex;
    /**
     * list of wooliebatlethreads that have finished
     */
    private ArrayList<WoolieBattleThread> battledwoolies;

    /**
     * constructor
     * @param woolies list
     * @param sportsComplex arenas
     */
    public Troll(ArrayList<Woolie> woolies,
                 SportsComplex sportsComplex){
        this.woolies=woolies;
        this.sportsComplex=sportsComplex;
    }

    /**
     * begins the competition by imparting a troll to batles
     */
    public void beginBattleRoyale() {
        int i=1;
        while(woolies.size()>1) {
            ArrayList<Woolie> winners=new ArrayList<>();
            System.out.println("Round " + i + " is about to begin");
            System.out.println("The contestants for this round are - ");
            for (Woolie w : woolies) {
                System.out.println(w.toString());
            }
            round();
            while (battledwoolies.size() > 0) {
                for (int m=0; m<battledwoolies.size(); m++) {
                    WoolieBattleThread wbt = battledwoolies.get(m);
                    if (!wbt.isAlive()) {
                        winners.add(wbt.getWinner());
                        woolies.add(wbt.getWinner());
                        battledwoolies.remove(wbt);
                    }
                }
            }
            System.out.println("Round "+i+" has ended");
            i++;
            System.out.println("The contestants left after this round are:");
            for (Woolie w1 : winners) {
                System.out.println(w1.toString());
            }
            if (winners.size()==1){
                System.out.println(winners.get(0).getName()+" is the winner");
            }
        }
    }

    /**
     * it calls the run method and is specific to one round
     */
    public void round(){
        battledwoolies=new ArrayList<>();
        Random random = new Random();
        while(woolies.size()>1) {
            int plus1 = random.nextInt(woolies.size());
            Woolie fifghter2=woolies.remove(plus1);
            int plus2 = random.nextInt(woolies.size());
            WoolieBattleThread t=new WoolieBattleThread(fifghter2,woolies.remove(plus2),sportsComplex);
            battledwoolies.add(t);
            t.start();
        }
    }

}
