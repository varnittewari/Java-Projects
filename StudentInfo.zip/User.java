import org.omg.IOP.Codec;
import java.util.Collection;
import java.util.*;
import java.util.Comparator;

/**
 * Created by varni on 2/24/2017.
 */
public class User implements Comparable<User> {
    /**
     *The username (unique)
     */
    private String username;
    /**
     * The user type
     */
    private User.UserType type;
    /**
     * The courses the professor is teaching, or student is enrolled in
     */
    private TreeSet<Course> courses;

    /**
     * types of users
     */
    public enum UserType{
        PROFESSOR,
        STUDENT
    }

    /**
     * Create a new user.
     * @param username name of the user
     * @param type typ fo the user
     * @param comp comparing method
     */
    public User(String username, User.UserType type, Comparator<Course> comp){
        this.username=username;
        this.type=type;
        courses= new TreeSet<>(comp);
    }

    /**
     * gets the name
     * @return string
     */
    public String getUsername(){
        return this.username;
    }

    /**
     * gets the type
     * @return type
     */
    public User.UserType getType(){
        return this.type;
    }

    /**
     * adds a course
     * @param course course
     * @return boolean
     */
    public boolean addCourse(Course course){
        courses.add(course);
        return true;
    }

    /**
     * removes a course
     * @param course course
     * @return boolean
     */
    public boolean removeCourse(Course course){
        courses.remove(course);
        return true;
    }

    /**
     * converts the user to a string
     * @return string
     */
    @Override
    public String toString() {
        ArrayList<String> str11= new ArrayList<>();
        for (Course c111:courses){
            str11.add(c111.getName());
        }
        return "User{" +
                "username='" + username + '\'' +
                ", type=" + type +
                ", courses=" + str11 +
                '}';
    }

    /**
     * gets all the courses
     * @return collection
     */
    public Collection<Course> getCourses(){
        return this.courses;
    }

    /**
     * comparing method
     * @param other comparing object
     * @return boolean
     */
    public boolean equals(Object other){
        if (other instanceof Course){
            Course p=(Course) other;
            return this.username.compareTo(((Course) other).getName())==0;
        }
        return false;
    }

    /**
     * gets the hashcode
     * @return int
     */
    public int hashCode(){
        return courses.hashCode();
    }

    /**
     * comparing method
     * @param other comparing object
     * @return int
     */
    public int compareTo(User other){
        int result= this.username.compareTo(other.getUsername());
        return result;
    }
}
