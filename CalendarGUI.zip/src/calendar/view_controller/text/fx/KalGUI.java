package calendar.view_controller.text.fx;

import calendar.model.Appointment;
import calendar.model.Calendar;
import calendar.model.Time;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.LinkedList;
import java.util.List;

/**
 * Created by Varnit Tewari on 4/24/2017.
 */
public class KalGUI extends Application{
    /**
     * calndar class model to work on
     */
    private Calendar model;
    /**
     * textfield to enter data
     */
    private TextField entertime;
    /**
     * textfield to enter string
     */
    private TextField enterwhat;

    private List<Button> lst;

    /**
     * initializes the model
     * @param arg string
     */
    public void init(String arg) {
        if (arg==null){
            model=new Calendar(28);
        }else {
            try{
                model = Calendar.fromFile(arg);
            }
            catch(Exception b){
                model=new Calendar(28);
            }
        }
    }

    /**
     * another window to work on which gives the list of appointments and also adds and removes
     * @param i date
     */
    public void appointments(int i){
        Stage stage = new Stage();
        stage.setTitle("Appointments on this day");

        VBox bp=new VBox();

        Button add=new Button("Add");
        Button rem=new Button("Remove");

        FlowPane fp=new FlowPane();
        fp.getChildren().addAll(add,rem);

        bp.getChildren().addAll(fp);

        if(!model.appointmentsOn(i).isEmpty()) {
            List<Appointment> lst = model.appointmentsOn(i);
            for (Appointment appo : lst) {
                TextField tf = new TextField(appo.toString());
                bp.getChildren().add(tf);
            }
        }

        add.setOnAction(event -> {
           newAppointment(i);
            stage.close();
        });
        
        rem.setOnAction(event -> {
            removing(i);
            stage.close();
        });

        Scene scene=new Scene(bp,300,400);
        stage.setScene(scene);
        stage.show();
    }

    /**
     * another window which helps in removing the appointment
     * @param i date
     */
    public void removing(int i){

        Stage stage=new Stage();
        Label time=new Label("Time:");
        entertime=new TextField();
        FlowPane fp1=new FlowPane();
        fp1.getChildren().addAll(time,entertime);
        Button remove=new Button("Remove");
        remove.setOnAction(event -> {
            final String ti=entertime.getText();
            Time t = new Time(0,0);
            if (!ti.isEmpty()) {
                t = Time.fromString(ti);
            }
            Appointment newapp=new Appointment(i,t,"");
            model.remove(newapp);
            Stage stage1 = (Stage) remove.getScene().getWindow();
            stage1.close();
        });

        VBox vb=new VBox();
        vb.getChildren().addAll(fp1,remove);

        Scene scene=new Scene(vb,200,200);
        stage.setScene(scene);
        stage.show();
    }

    /**
     * helps adding a new appointment to the list of appointments
     * @param i date
     */
    public void newAppointment(int i){

        Stage stage=new Stage();
        stage.setTitle("New Appointment");

        List<Appointment> names=model.appointmentsOn(i);

        Label time=new Label("Time:");
        entertime=new TextField();
        FlowPane fp1=new FlowPane();
        fp1.getChildren().addAll(time,entertime);
        Label what=new Label("What:");
        enterwhat=new TextField();
        FlowPane fp2=new FlowPane();
        fp2.getChildren().addAll(what,enterwhat);

        Button save=new Button("Save");
        save.setOnAction(event -> {
            final String wh=enterwhat.getText();
            final String ti=entertime.getText();
            Time t = new Time(0,0);
            if (!ti.isEmpty()) {
                t = Time.fromString(ti);
                //String[] tili = ti.split(":");
                //t = new Time(Integer.parseInt(tili[0]), Integer.parseInt(tili[1]));
            }
            Appointment newapp=new Appointment(i,t,wh);
            model.add(newapp);
            Stage stage1 = (Stage) save.getScene().getWindow();
            stage1.close();
            //names.add(newapp);
        });

        VBox vb=new VBox();
        vb.getChildren().addAll(fp1,fp2,save);

        Scene scene=new Scene(vb,200,200);
        stage.setScene(scene);
        stage.show();
    }

    /**
     * main window of the calendar
     * @param stage stage
     */
    @Override
    public void start(Stage stage){
        List<String> parameters = getParameters().getUnnamed();
        if(parameters.isEmpty()){
            init(null);
        }
        else{
            init(parameters.get(0));
        }

        stage.setTitle("Calendar");

        FlowPane fp = new FlowPane();
        FlowPane fp1 = new FlowPane();
        FlowPane fp2 = new FlowPane();
        FlowPane fp3 = new FlowPane();
        lst=new LinkedList<>();
        for ( int i=1;i<model.numDays();i++) {
            final int d=i;
            Button btn = new Button(String.valueOf(i));
            btn.setOnAction(event -> appointments(d));
            lst.add(btn);

            btn.setMinWidth(100.0);
/**
    );
 */
            if (fp.getChildren().size() < 8) {
                fp.getChildren().add(btn);
            }
            else  if (fp1.getChildren().size() < 8) {
                fp1.getChildren().add(btn);
            }
            else if (fp2.getChildren().size() < 8) {
                fp2.getChildren().add(btn);
            }
            else{
                fp3.getChildren().add(btn);
            }
        }

        Button save=new Button("Save Calendar");
        save.setMinWidth(150);

        GridPane gp=new GridPane();
        gp.add(fp,0,1);
        gp.add(fp1,0,2);
        gp.add(fp2,0,3);
        gp.add(fp3,0,4);
        gp.add(save,0,5);

        gp.setAlignment(Pos.TOP_CENTER);

        save.setOnAction(event -> {
            try{
                model.toFile();
            }catch(Exception e){

            }
        });
        Scene scene=new Scene(gp,500,300);
        stage.setScene(scene);
        stage.show();
    }

    /**
     * main method to launch the whole stage
     * @param args string
     */
    public static void main(String[] args){
        Application.launch(args);
    }
}
